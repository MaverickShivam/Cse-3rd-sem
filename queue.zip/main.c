#include<stdio.h>
#include<conio.h>
int front=-1;
int rear=-1;
int queue[100];
void push(int x)
{
    if(front==-1&& rear==-1)
    {
        front=0;
        rear=0;
        queue[0]=x;
    }
    else if(rear<100)
    {
        rear=rear+1;
        queue[rear]=x;
    }
}
int pop()
{
    if(front<=rear)
    {
        int data= queue[front];
        front=front+1;
        return data;
    }
    else
    {
        printf("Not possible");
    }
    
}
void display()
{
    int i;
    for(i=front;i<=rear;i++)
    {
        printf("%d\n",queue[i]);
    }
}
void main()
{
    push(10);
    push(20);
    push(30);
    push(40);
    pop();
    pop();
    pop();
    
    display();
    
    
}