#include<stdio.h>
#include<conio.h>
int max=5;
int queue[5];
int front=-1;
int rear=-1;
void insert(int x)
{
    if(front==-1&&rear==-1)
    {
        front=front+1;
        rear=rear+1;
        queue[front]=x;
    }
    else
    {
        if((rear+1)%max==front)
        {
            printf("full\n");
        }
        else
        {
            rear=(rear+1)%max;
            queue[rear]=x;
        }
    }
}
void delete()
{
    if(front==rear)
    {
        printf("stack empty\n");
        front=-1;
        rear=-1;
    }
    else
    {
        front=(front+1)%max;
    }
}
void show()
{
    int i=front;
    while(i!=rear)
    {
        printf("%d\n",queue[i]);
        i=(i+1)%max;
    }
    printf("%d\n",queue[i]);
}

void main()
{
    insert(30);
    show();
    
}
