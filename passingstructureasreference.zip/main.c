#include<stdio.h>
#include<conio.h>
struct student
{
    int data;
};
int qualify(struct student s)
{
    if(s.data>50)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void feedvalue(struct student *s,int x)
{
    s->data=x;
}
void main()
{
    struct student s[10];
    int i;
    for(i=0;i<10;i++)
    {
        int data;
        scanf("%d",&data);
        feedvalue(&s[i],data);
        
    }
    for(i=0;i<10;i++)
    {
        printf("%d",s[i].data);
        if(qualify(s[i]))
        {
            printf("Eligible\n");
        }
        else
        {
            printf("Not Eligible\n");
        }
    }
}