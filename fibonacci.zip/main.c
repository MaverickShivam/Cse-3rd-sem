#include<stdio.h>
int fibo(int x)
{
    int term;
    if(x==0 || x==1)
    {
        term= x;
    }
    else
    {
        term=(fibo(x-1)+fibo(x-2));
    }
    return term;
}
void main()
{
    printf("%d",fibo(6));
}
