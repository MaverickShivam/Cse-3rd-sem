#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node* next;
};
struct node *head;
struct node* createnode(int x)
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->next=NULL;
    return temp;
}
void appendatend(int x)
{
    if(head==NULL)
    {
        head=createnode(x);
    }
    else
    {
        struct node *p;
        p=head;
        while(p->next!=NULL)
        {
            p=p->next;
        }
        p->next=createnode(x);
    }
}
void appendatfront(int x)
{
    if(head==NULL)
    {
        head=createnode(x);
    }
    else
    {
        struct node *p;
        p=createnode(x);
        p->next=head;
        head=p;
    }
}
void show()
{
    struct node *p;
    p=head;
    while(p!=NULL)
    {
        printf("\n%d",p->data);
        p=p->next;
    }
}
int length()
{
    struct node*p;
    p=head;
    int len=0;
    while(p!=NULL)
    {
        p=p->next;
        len=len+1;
    }
    return len;
}
void delete(int pos)
{
    if(pos>1 && pos<=length())
    {
        struct node *p;
        p=head;
        int i;
        for(i=1;i<pos-1;i++)
        {
            p=p->next;
        }
        p->next=p->next->next;
    }
    else if(pos==1 && pos<=length())
    {
        head=head->next;
    }
    else
    {
        printf("\nDeletion Not allowed");
    }
}
void appendatpos(int pos,int data)
{
    if(pos>1&&pos<=length())
    {
        int i;
        struct node *p,*q;
        p=head;
        for(i=1;i<pos-1;i++)
        {
            p=p->next;
        }
        q=createnode(data);
        q->next=p->next;
        p->next=q;
    }
}
void main()
{
    while(1)
    {
        printf("\n1.Append at end\n2.Append at front\n3.Print\n4.Delete\n5.Append at position");
        int choice;
        printf("\nEnter Your Choice: ");
        scanf("%d",&choice);
        if(choice==1)
        {
            int data;
            printf("\nFeed the value: ");
            scanf("%d",&data);
            appendatend(data);
        }
        else if(choice==2)
        {
            int data;
            printf("\nFeed the value: ");
            scanf("%d",&data);
            appendatfront(data);
        }
        else if(choice==3)
        {
            show();
        }
        else if(choice==4)
        {  
            int pos;
            printf("\nEnter the Position: ");
            scanf("%d",&pos);
            delete(pos);
        }
        else if(choice==5)
        {
            int pos,data;
            printf("\nEnter the Position: ");
            scanf("%d",&pos);
            printf("\nEnter the Value: ");
            scanf("%d",&data);
            appendatpos(pos,data);
        }
    }
}
