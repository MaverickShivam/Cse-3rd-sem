#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head;
struct node *last;
struct node* createnode(int x)
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->next=NULL;
    return(temp);
}
int length=0;
void appendatfront(int x)
{
    if(head==NULL)
    {
        struct node *p;
        p=createnode(x);
        head=p;
        last=head;
        head->next=head;
        length=length+1;
    }
    else
    {
        struct node *p;
        p=createnode(x);
        p->next=head;
        head=p;
        last->next=head;
        length++;
    }
}
void appendatpos(int x,int pos)
{
    if(pos==length+1)
    {
        struct node *p;
        p=createnode(x);
        struct node *temp;
        temp=head;
        while(temp->next!=head)
        {
            temp=temp->next;
        }
        temp->next=p;
        last=p;
        last->next=head;
        length++;
    }
    else if(pos>1 && pos<=length)
    {
        struct node *temp;
        temp=head;
        int i=1;
        while(i<pos-1)
        {
            temp=temp->next;
            i++;
        }
        struct node *p;
        p=createnode(x);
        p->next=temp->next;
        temp->next=p;
        length++;
    }
    else if(pos==1)
    {
        appendatfront(x);
    }
    else
    {
        printf("Position out of range");
    }
}
void main()
{
    appendatfront(0);
    appendatfront(0);
    appendatfront(0);
    appendatfront(0);
    appendatpos(1,1);
    appendatpos(5,5);
    struct node *p;
    p=head;
    int i=0;
    while(i<length)
    {
        printf("%d \n",p->data);
        p=p->next;
        i++;
    }
    printf("length: %d",length);
}