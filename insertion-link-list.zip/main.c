#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *next;
};
struct node *head;
struct node* createnode(int x)
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    temp->next=NULL;
    temp->data=x;
    return temp;
}
void appendatfront(int x)
{
    if(head==NULL)
    {
        head=createnode(x);
    }
    else
    {
        struct node *p;
        p=createnode(x);
        p->next=head;
        head=p;
    }
}
void appendatpos(int pos,int x)
{
    if(pos==1)
    {
        appendatfront(x);
        return;
    }
    struct node *p;
    p=head;
    for(int i=1;i<pos-1;i++)
    {
        p=p->next;
    }
    struct node *q;
    q=createnode(x);
    q->next=p->next;
    p->next=q;
}
void appendatend(int x)
{
    if(head==NULL)
    {
        head=createnode(x);
    }
    else
    {
        struct node *p;
        p=head;
        while(p->next!=NULL)
        {
            p=p->next;
        }
        p->next=createnode(x);
    }
}
void display()
{
    struct node *p;
    p=head;
    while(p!=NULL)
    {
        printf("%d\n",p->data);
        p=p->next;
    }
}
void main()
{
    appendatfront(50);
    appendatfront(40);
    appendatfront(30);
    appendatend(60);
    appendatpos(2,2);
    display();
}