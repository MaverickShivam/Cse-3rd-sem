#include<stdio.h>
int factorial(int x)
{
    int fac;
    if(x==1)
    {
        fac=1;
    }
    else
    {
        fac=factorial(x-1)*x;
    }
    return fac;
}
void main()
{
    printf("%d",factorial(6));
}