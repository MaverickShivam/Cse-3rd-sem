#include<stdio.h>
#include<conio.h>
#include<math.h>
int stack[20];
int top=-1;
void push(int x)
{
    top=top+1;
    stack[top]=x;
}
int pop()
{
    int var =stack[top];
    top=top-1;
    return var;
}
int isoperator(char x)
{
    if(x=='+'||x=='-'||x=='*'||x=='/'||x=='^')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void main()
{
    char expr[40];
    scanf("%s",expr);
    int i=0;
    while(expr[i]!='\0')
    {
        if(isoperator(expr[i]))
        {
            int n1=pop();
            int n2=pop();
            if(expr[i]=='+')
            {
                push(n2+n1);
            }
            else if(expr[i]=='-')
            {
                push(n2-n1);
            }
            else if(expr[i]=='*')
            {
                push(n2*n1);
            }
            else if(expr[i]=='/')
            {
                push(n2/n1);
            }
            else if(expr[i]=='^')
            {
                push(pow(n2,n1));
            }
        }
        else
        {
            push((int)expr[i]-48);
        }
        i=i+1;
    }
    printf("%d",pop());
}