#include<stdio.h>
#include<conio.h>
int len=0;
int stack[100];
void push(int x)
{
    if(len<100)
    {
        stack[len]=x;
        len=len+1;
    }
    else
    {
        printf("Stack Overfow\n");
    }
}
int pop()
{
    if(len>0)
    {
        len=len-1;
        return stack[len-1];
    }
    else
    {
        printf("Stack Underflow\n");
    }
}
void display()
{
    int i;
    for(i=0;i<len;i++)
    {
        printf("%d\n",stack[i]);
    }
}
void main()
{
    push(10);
    push(20);
    push(40);
    pop();
    push(30);
    push(40);
    display();
}