#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node 
{
    struct node *left;
    int data;
    struct node *right;
};

struct node* createnode(int data)
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    temp->left=NULL;
    temp->data=data;
    temp->right=NULL;
    return temp;
}
struct node* insert(struct node *root,int data)
{
    if(root==NULL)
    {
        root=createnode(data);
    }
    else if(data<=root->data)
    {
        root->left=insert(root->left,data);
    }
    else if(data>root->data)
    {
        root->right=insert(root->right,data);
    }
    return root;
}
void inorderdisplay(struct node *root)
{
    if(root!=NULL)
    {
        inorderdisplay(root->left);
        printf("%d\n",root->data);
        inorderdisplay(root->right);  
    }
    else
    {
        return;
    }
    
}
void search(struct node *root,int data)
{
    if(root!=NULL)
    {
        if(data>root->data)
        {
            search(root->right,data);
        }
        else if(data<root->data)
        {
            search(root->left,data);
        }
        else
        {
            printf("Data Found");
            return;
        }
    }
    else
    {
        printf("Not found");
        return;
    }
    
}
void main()
{
    struct node *root;
    root=NULL;
    root=insert(root,30);
    root=insert(root,40);
    root=insert(root,10);
    root=insert(root,20);
    root=insert(root,60);
    root=insert(root,10);
    inorderdisplay(root);
    search(root,10);
    
}

