#include<stdio.h>
#include<conio.h>
int top=-1;
char stack[20];
void push(char x)
{
    top=top+1;
    stack[top]=x;
}
char pop()
{
    char var=stack[top];
    top=top-1;
    return var;
}
int priority(char x)
{
    if(x=='^')
    {
        return 3;
    }
    else if(x=='*'||x=='/')
    {
        return 2;
    }
    else if(x=='+'|| x=='-')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
void main()
{
    char expr[40];
    scanf("%s",expr);
    int i=0;
    while(expr[i]!='\0')
    
    {
        if(expr[i]=='(')
        {
            push(expr[i]);
        }
        else if(expr[i]==')')
        {
            while(stack[top]!='(')
            {
                printf("%c",pop());
            }
            pop();
        }
        else if(priority(expr[i])==0)
        {
            printf("%c",expr[i]);
        }
        else if(priority(expr[i])>0)
        {
            if(priority(stack[top])<priority(expr[i]))
            {
                push(expr[i]);
            }
            else
            {
                while(priority(stack[top])>=priority(expr[i])&&top>-1)
                {
                    printf("%c",pop());
                }
                push(expr[i]);
            }
        }
        i=i+1;
    }
    while(top!=-1)
    {
        printf("%c",pop());
    }
}
