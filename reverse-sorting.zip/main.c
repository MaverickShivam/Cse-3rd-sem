#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
struct node 
{
    int data;
    struct node *next;
};
struct node *head;
struct node* createnode(int x)
{
    struct node *temp;
    temp=(struct node*)malloc(sizeof(struct node));
    temp->data=x;
    temp->next=NULL;
}
void append(int x)
{
    if(head==NULL)
    {
        head=createnode(x);
    }
    else
    {
        struct node *p;
        p=createnode(x);
        p->next=head;
        head=p;
    }
}
int len()
{
    struct node *p;
    p=head;
    int len=0;
    while(p!=NULL)
    {
        p=p->next;
        len++;
    }
    return len;
}
void sort()
{
    struct node*p;
    for(int i=0;i<len()-1;i++)
    {
        p=head;
        for(int j=0;j<len()-1;j++)
        {
            if(p->next->data<p->data)//ascending order
            {
                int tempdata;
                tempdata=p->data;
                p->data=p->next->data;
                p->next->data=tempdata;
            }
            p=p->next;
        }
    }
}
void reverse()
{
    struct node *p,*q;
    p=head;
    while(p!=NULL)
    {
        if(q==NULL)
        {
            q=createnode(p->data);
        }
        else
        {
            struct node *t;
            t=createnode(p->data);
            t->next=q;
            q=t;
        }
        p=p->next;
        
    }
    head=q;
    
}
void show()
{
    struct node *p;
    p=head;
    while(p!=NULL)
    {
        printf("%d\n",p->data);
        p=p->next;
    }
}
void main()
{
    append(10);
    append(9);
    append(1);
    append(8);
    append(12);
    show();
    sort();
    printf("After sorting\n");
    show();
    printf("After reversing\n");
    reverse();
    show();
}